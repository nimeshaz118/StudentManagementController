﻿using StudentManagement.Models;

namespace StudentManagementAPI.Services;


public interface IStudentService
{

    List<Student> GetAllStudents();

    Student GetStudentById(int id);

    void AddStudent(Student student);

    bool UpdateStudent(int id, Student student);

    bool DeleteStudent(int id);

}