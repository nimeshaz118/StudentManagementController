﻿using StudentManagement.Models;


namespace StudentManagementAPI.Services;


public class StudentService : IStudentService
{

    private List<Student> students = new List<Student>();


    public List<Student> GetAllStudents()
    {
        return students;
    }


    public Student GetStudentById(int id)
    {
        return students.FirstOrDefault(x => x.StudentId == id);
    }



    public void AddStudent(Student student)
    {
        students.Add(student);
    }



    public bool UpdateStudent(int id, Student student)
    {

        var existingStudent = students
            .FirstOrDefault(x => x.StudentId == id);


        if (existingStudent == null)
        {
            return false;
        }


        existingStudent.Name = student.Name;
        existingStudent.Age = student.Age;
        existingStudent.Email = student.Email;
        existingStudent.Course = student.Course;


        return true;
    }



    public bool DeleteStudent(int id)
    {

        var student = students
            .FirstOrDefault(x => x.StudentId == id);


        if (student == null)
        {
            return false;
        }


        students.Remove(student);

        return true;
    }

}